//package inClassWork;

public class CheckingAccount extends BankAccount
{
	private static double FEE =.15;
	
	public CheckingAccount(String name, double amount)
	{
		super(name,amount);
		setAccountNumber(getAccountNumber() + "-10");
	}
	
	public boolean withdraw(double amount)
	{
		double amountWithFees = (amount + FEE);
		return super.withdraw(amountWithFees);
	}
	
	
}
