//package inClassWork;

public class SavingsAccount extends BankAccount
{
	private static double rate = 0.025; 
	private static int savingsNumber = 0;
	private String accountNumber;
	
	public SavingsAccount(String name, double amount)
	{
		super(name,amount);
		this.accountNumber = super.getAccountNumber() + "-" + savingsNumber;
	}
	public void postInterest()
	{
		double monthlyInterest = (rate/12);
		double monthlyAmount = monthlyInterest * getBalance();
		deposit(monthlyAmount);
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public SavingsAccount(SavingsAccount newSavingsAccount, double amount)
	{
		super(newSavingsAccount,amount);
		this.accountNumber = super.getAccountNumber() + "-" + savingsNumber;
	}


}
